# The SASS Test

Well hello! Here is the "mostly" completed SASS test.

## Instructions to develop locally
1. Clone repo
2. Run `npm-install`
3. Run `npm-start`

Have fun!

![cover-photo](src/assets/images/readme.jpg)